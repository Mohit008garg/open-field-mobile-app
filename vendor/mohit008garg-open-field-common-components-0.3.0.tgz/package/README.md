# @mohit008garg/open-field-common-components

Shared **design tokens** and **platform-split UI components** for the OpenField
apps — consumed by `open-field-mobile-app` (React Native), `open-field-fe` and
`open-field-fe-admin` (React web). Published privately to **GitHub Packages**.

## How sharing works (platform-split)

React Native and React DOM don't share UI primitives, so each component ships
**two implementations behind one import**:

```
src/components/Button/
├── Button.types.ts     # one shared Props contract
├── Button.tsx          # WEB implementation (real DOM, default file)
├── Button.native.tsx   # React Native implementation
└── index.ts            # export * from './Button.types'; export { Button } from './Button';
```

- **Web bundlers** (Vite/webpack) and **tsc** resolve the unsuffixed `Button.tsx`.
- **Metro** (React Native) automatically prefers `Button.native.tsx`.

Both implementations import the **same tokens** (`src/tokens`) and the **same
props type**, so the API and look stay consistent across platforms. Pure logic is
shared too (e.g. `Avatar.shared.ts`).

The build (`tsc`) preserves these suffixes in `dist/`, so the consuming app's own
bundler does the platform resolution:

```
dist/components/Button/
├── Button.js        ← web
├── Button.native.js ← native
├── Button.d.ts / Button.native.d.ts / Button.types.d.ts
```

## What's exported

```ts
import {
  // tokens
  colors, spacing, radius, fontSize,
  // components
  Button, Card, Avatar, Chip,
} from '@mohit008garg/open-field-common-components';
```

> Starter set only. Port the rest of the mobile components (TextField, SearchBar,
> SegmentedTabs, ScreenHeader, feature cards, …) using the same 3-file pattern.

## Develop

```bash
npm install
npm run build      # tsc -> dist (preserves .native/.web)
npm run typecheck
```

## Storybook (component catalog)

A Storybook documents every component and lets developers play with props live:

```bash
npm run storybook        # dev server at http://localhost:6006
npm run build-storybook  # static build -> storybook-static/
```

Storybook runs the **web** implementations (React + Vite) and reads the shared
`*.types.ts`, so the controls (variants, sizes, flags) reflect the exact same
prop contract the native side uses. Add a `Name.stories.tsx` next to each
component as you port it.

## Consuming the package (mobile / fe / admin)

1. Add an `.npmrc` to the consuming repo so the scope resolves to GitHub Packages:

   ```
   @mohit008garg:registry=https://npm.pkg.github.com
   //npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
   ```

   Set `GITHUB_TOKEN` to a PAT with **`read:packages`** (in the shell/CI env).

2. Install:

   ```bash
   npm install @mohit008garg/open-field-common-components
   ```

3. Use the same import on every platform:

   ```tsx
   import { Button, colors } from '@mohit008garg/open-field-common-components';

   <Button label="Get Started" variant="primary" onPress={handlePress} />
   ```

   - **Mobile (Expo/Metro)** resolves the `.native` files automatically — no config.
   - **Web (Vite/webpack)** resolves the default (web) files — no config; the
     web build never imports `react-native`.

`react` / `react-dom` / `react-native` are **peer dependencies** — provided by
each consuming app, not bundled here.

## Publishing (GitHub Packages, private)

Publishing runs in **CI** (`.github/workflows/publish.yml`) using the workflow's
built-in `GITHUB_TOKEN` (no personal token needed). Trigger it by pushing a
version tag:

```bash
npm version patch            # bumps version + creates a git tag
git push --follow-tags       # tag push triggers the Publish workflow
```

You can also run the **Publish package** workflow manually (workflow_dispatch).

To publish/install locally instead, add a PAT to your user `~/.npmrc`:

```
//npm.pkg.github.com/:_authToken=YOUR_PAT
```

(`read:packages` to install, `write:packages` to publish). `publishConfig.registry`
already points at `https://npm.pkg.github.com`, and the package is linked to this
repo via the `repository` field.
